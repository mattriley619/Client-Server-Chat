
public class ChatClient
{
    public static void main(String[] args)
    {
        new FrameClass();

    }



}